package com.example.aplicacioncodigos;

public class codigo {
    public String Codigo_APP;
    public String codigo;


    public void setCodigoApp(String Codigo_APP) { this.Codigo_APP = Codigo_APP; }
    public String getCodigo(){return codigo;}
}
